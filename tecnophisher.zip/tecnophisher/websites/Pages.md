# **ZPhisher**
#### Powered by ***HTR-TECH*** (**@tahmid.rayat**)
***
***
I am not responsible for any misuse of this tool.
***
***
# Available Phishing Pages
**1) Facebook:**
- Facebook Normal Login Page
- Fake Security Login Method (DarkSecDevelopers)
- Facebook Voting Poll Method (DarkSecDevelopers)
- Messenger Login Page (New)

**2) Instagram:**
- Normal Login Page
- Instagram Auto Follower Phishing Page (thelinuxchoice)
- Instagram Badge Verify Method (DarkSecDevelopers)

**3) Google**
- Google Old Login Page
- Google New Login Page
- Google Voting Poll Method (DarkSecDevelopers)

**4) Adobe Login Page**

**5) Badoo Login Page**

**6) CryptoCoinSniper Login Page**

**7) Deviantart Login Page**

**8) Dropbox Login Page**

**9) Ebay Login Page**

**10) Github Login Page**

**11) Linkedin Login Page**

**12) Microsoft Login Page**

**13) Netflix Login Page**

**14) Origin Login Page**

**15) Paypal Login Page**

**16) Pinterest Login Page**

**17) Playstation  Login Page**

**18) Protonmail Login Page**

**19) Reddit Login Page**

**20) Snapchat Login Page**

**21) Spotify Login Page**

**22) Stackoverflow Login Page**

**23) Steam Login Page**

**24) Twitch Login Page**

**25) Twitter Login Page**

**26) Vk Login Page**

**27) Vk Poll Method (Hiddeneye)**

**28) Wordpress  Login Page**

**29) Yahoo Login Page**

**30) Yandex Login Page**
***
***

***Donot Copy My Work***
